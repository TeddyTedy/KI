Startposition:

Spalte 2 unten

Zielposition

Spalte 3 oben